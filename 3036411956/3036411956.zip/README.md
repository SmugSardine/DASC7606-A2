Use the '--label' argument to generate a specified digit from 0 to 9. For unconditional generation, simply omit this argument. for example, to generate images of 9, input:

```
> python train_mnist.py --label 9
```